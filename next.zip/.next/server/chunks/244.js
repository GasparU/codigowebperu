"use strict";
exports.id = 244;
exports.ids = [244];
exports.modules = {

/***/ 7244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/whatsapp.png
/* harmony default export */ const whatsapp = ({"src":"/_next/static/media/whatsapp.010d6c86.png","height":600,"width":598,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA90lEQVR42i3PzSsEARjH8ScvBwdHRymn5abcKHF2cZH24CB/BVcu62JTu4UkZWtvlNQqBy+NyWJnxDIpO9qmNSjKYe28PF9L+7n++h2+EhK1SROQQFnQWBeBAWmq8/O/CcrM+auhKWeV9FOGy7crUJLSevYaNbO++5xn+X4l6DCGg0FzgqJ/3QD6BJhbslKUPx7CQ7eAFAQ5ljBT3oCIeUGZ3rzbZup0Nir5Nje+xc5jLkjbWYCkAD0nlbNP2RNGjiZ13zmI1u0tLM+uAt2iDR1131++Liqmm7vNs1bMUqpaDgFD8seref3xd5wAulDGgHGgsxXQ/guw3bFVq2E9ngAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/Layout.js





const Layout = ({ children , className =""  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `w-full h-full inline-block z-0 bg-light p-32 dark:bg-dark xl:p-24 lg:p-16 md:p-12 sm:p-8 ${className}`,
        children: [
            children,
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                href: "https://api.whatsapp.com/send?phone=51929668883",
                className: "fixed right-16 bottom-16 inline-block w-24 ",
                target: "_blank",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute animate-ping rounded-full w-24 h-24 bg-whatsapp bottom-1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: whatsapp,
                        alt: "Jose Gaspar",
                        className: "w-full h-auto"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Layout = (Layout);


/***/ })

};
;