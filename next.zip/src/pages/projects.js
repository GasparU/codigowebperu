import React from 'react'
import Head from 'next/head'
import Layout from '@/components/Layout'
import AnimatedText from '@/components/AnimatedText'
import Link from 'next/link'
import Image from 'next/image'
import { GithubIcon } from '@/components/Icons'
import project1 from "../../public/images/projects/crypto-screener-cover-image.jpg"
import fondo1 from "../../public/images/projects/fondo1.png"
import fondo2 from "../../public/images/projects/fondo2.png"
import fondo3 from "../../public/images/projects/fondo3.png"
import fondo4 from "../../public/images/projects/fondo4.png"
import { motion } from 'framer-motion'
import TransitionEffect from '@/components/TransitionEffect';
import Education from '@/components/Education'

const FramerImage = motion(Image)

const FeaturedProject = ({ type, title, summary, img, link, github }) => {
    return (
        <article className='w-full flex items-center justify-between relative rounded-br-2xl rounded-3xl border border-solid
         border-blueskay bg-light shadow-2xl p-12  dark:bg-dark dark:border-greenday
        lg:flex-col lg:p-8 xs:rounded-2xl xs:rounded-br-3xl xs:p-4
        '>
            <div className='absolute top-0 -right-3 -z-10 w-[100%] h-[103%] rounded-[2.5rem] bg-blueskay dark:bg-greenday 
            rounded-br-3xl xs:-right-2 sm:h-[102%] xs:w-full xs:rounded-[1.5rem]
            ' />
            {/* Esto era un Link */}
            <div 
                className='w-1/2  overflow-hidden rounded-lg lg:w-full '
            >
                <FramerImage src={img} alt={title} className='w-full h-auto'
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                    priority
                    sizes='(max-width: 768px) 100vw, 
              (max-width: 1200px) 50vw, 
              50vw'
                />
            </div>
            <div className='w-1/2 flex flex-col items-start justify-between pl-6 lg:w-full lg:pl-0 lg:pt-6  '>
                <span className='text-primary font-medium text-xl dark:text-primaryDark xs:text-base'>{type}</span>
                {/* Esto era un Link */}
                <div  className='underline-offset-2'>
                    <h2 className='my-2 w-full text-left text-4xl font-bold dark:text-light sm:text-sm'>{title}</h2>
                </div>
                <p className='my-2 font-medium text-dark dark:text-light sm:text-sm '>{summary}</p>
                <div className='mt-2 flex items-center'>
                    {/* Esto era un Link */}
                    <Link href={link} target='_blank' className='w-10'>
                        <GithubIcon />
                    </Link>
                    {/* Esto era un Link */}
                    <Link href={link} target='_blank'
                        className='ml-4 rounded-lg bg-dark text-light p-2 px-6 text-lg font-semibold dark:bg-light dark:text-dark
                        sm:px-4 sm:text-base
                        '
                    >Ver Projecto</Link>
                </div>
            </div>

        </article>
    )
}

const Project = ({ title, type, img, link, github, summary }) => {
    return (
        <article className='w-full flex flex-col items-center justify-center rounded-2xl border border-solid border-blueskay bg-light p-6 relative dark:bg-dark
         dark:border-greenday xs:p-4 '>
            <div className='absolute top-0 -right-3 -z-10 w-[100%] h-[103%] rounded-[2rem] bg-blueskay rounded-br-3xl dark:bg-greenday
            md:-right-2 md:w-[101%] xs:h-[102%] xs:rounded-[1.5rem]
            ' />
            {/* Esto era un Link */}
            <div 
                className='w-full  overflow-hidden rounded-lg'
            >
                <FramerImage src={img} alt={title} className='w-full h-auto'
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                />
            </div>
            <div className='w-full flex flex-col items-start justify-between mt-4'>
                <span className='text-primary font-medium text-xl dark:text-primaryDark lg:text-lg md:text-base'>{type}</span>
                {/* Esto era un Link */}
                <div  className=' underline-offset-2'>
                    <h2 className='my-2 w-full text-left text-3xl font-bold lg:text-2xl '>{title}</h2>
                </div>
                <p className='my-2 font-medium text-dark'>{summary}</p>
                <div className='w-full mt-2 flex items-center justify-between'>
                    <Link href={link} target='_blank'
                        className=' text-lg font-semibold underline md:text-base '
                    >Ver Web</Link>
                    <Link href={github} target='_blank' className='w-8 md:w-6'>
                        {/* <GithubIcon /> */}
                    </Link>

                </div>
            </div>
        </article>
    )
}

const projects = () => {

    return (
        <>
            <Head>
                <title>Proyectos | JG</title>
                <meta name='description' content="Agregar descripción de SEO de About" />
            </Head>
            <TransitionEffect />
            <min className="w-full mb-16 flex flex-col items-center justify-center dark:text-light">
                <Layout className='pt-16'>
                    <AnimatedText text="Proyectos"
                        className='mb-16 lg:!text-7xl sm:mb-8 sm:!text-6xl xs:!text-4xl ' />

                    <div className='grid grid-cols-12 gap-24 gap-y-32 xl:gap-x-16 lg:gap-x-8 md:gap-y-24 sm:gap-x-0 '>
                        <div className='col-span-12'>
                            <FeaturedProject
                                title="LH Consulting"
                                img={fondo1}
                                summary="Página web para una consultora contable realizada con código puro de Next.js versión 13. Web super ligera, con apenas 4.5 megas de peso total y con los mejores resultado para SEO web en base a código web puro."
                                link="https://github.com/GasparU/lh-consulting"
                                github="/"
                                type="Proyecto en Código"
                            />
                        </div>
                        <div className='col-span-6 sm:col-span-12'>
                            <Project
                                title="AGM Consultoría Perú"
                                img={fondo2}
                                link="https://agmconsultoriaperu.com/"
                                github="."
                                summary="Consultora de Recursos Humanos y temas laborales. Desarrollo de web con la CMS de Wordpress, thema Astra y plugins complementarios. Posicionada con Yoast SEO."
                                type="Proyecto Wordpress"
                            />
                        </div>
                        <div className='col-span-6 sm:col-span-12'>
                            <Project
                                title="Sainc Ingenieros Constructores"
                                img={fondo3}
                                link="https://www.sainc.co/"
                                summary="Constructora con sede en Perú y Colombia. Web desarrollada con wordpress, jquery y bootstrap y posicionada con Yoast SEO."
                                github="."
                                type="Proyecto Wordpress"
                            />
                        </div>
                        <div className='col-span-12'>
                            <FeaturedProject
                                title="Panamedical"
                                img={fondo4}
                                summary="Empresa de distruidor de productos médicos. Trabajado en Wordpress, thema de Astra y maquetador Elementor. Posicionada con Yoast SEO."
                                link="https://www.panamedical.pe/"
                                github="."
                                type="Proyecto Wordpress"
                            />
                        </div>
                        <div className='col-span-6 sm:col-span-12'>
                            <Project
                                title="Proyecto 5 para editar"
                                img={project1}
                                link="/"
                                github="/"
                                type="Featured Project"
                            />
                        </div>
                        <div className='col-span-6 sm:col-span-12'>
                            <Project
                                title="Proyecto 6 para editar"
                                img={project1}
                                link="/"
                                github="/"
                                type="Featured Project"
                            />
                        </div>
                    </div>
                    <Education />
                </Layout>

            </min>

        </>
    )
}

export default projects